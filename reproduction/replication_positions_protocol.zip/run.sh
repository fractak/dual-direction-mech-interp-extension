#!/usr/bin/env bash
set -euo pipefail
bundle=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export HF_HUB_OFFLINE=1
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
case "${1:-}" in
 freeze) python -c 'import torch; assert torch.cuda.is_available(), "CUDA unavailable"'; python -m unittest tests.test_position_controls -v; python "$bundle/freeze.py"; exit ;;
 verify) python "$bundle/freeze.py" --verify; exit ;;
 smoke|run|all|export) action=$1 ;;
 *) echo 'Usage: bash run.sh freeze|verify|smoke|run|all|export' >&2; exit 2 ;;
esac
python "$bundle/freeze.py" --verify
if [[ "$action" == export ]]; then python "$bundle/export.py"; exit; fi
run_one() {
 local plan=$1 output=$2 adapter=$3
 local resume=()
 if [[ -f "$output/run.json" ]]; then resume=(--resume); fi
 if [[ ! -f "$output/run.json" ]] || ! python -c 'import json,sys; sys.exit(json.load(open(sys.argv[1])).get("complete") is not True)' "$output/run.json"; then
  python scripts/run_publication_study.py run --plan "$plan" --adapter-path "$adapter" --output-dir "$output" "${resume[@]}"
 fi
 python "$bundle/check.py" "$plan" "$output/run.json"
}
names=(llama31_8b_instruct_safety_lora llama31_8b_instruct_safety_lora_seed43 llama31_8b_instruct_safety_lora_seed44)
if [[ "$action" == smoke || "$action" == all ]]; then
 for i in "${!names[@]}"; do
  seed=$((42+i))
  run_one "artifacts/plans/family_replication/seed${seed}_smoke.json" "artifacts/runs/family_replication/seed${seed}_smoke" "artifacts/safety_finetuning/${names[i]}"
 done
 run_one artifacts/plans/position_control/smoke.json artifacts/runs/position_control/smoke "artifacts/safety_finetuning/${names[0]}"
fi
if [[ "$action" == run || "$action" == all ]]; then
 for seed in 42 43 44; do
  python "$bundle/check.py" "artifacts/plans/family_replication/seed${seed}_smoke.json" "artifacts/runs/family_replication/seed${seed}_smoke/run.json"
 done
 python "$bundle/check.py" artifacts/plans/position_control/smoke.json artifacts/runs/position_control/smoke/run.json
 for i in "${!names[@]}"; do
  seed=$((42+i))
  run_one "artifacts/plans/family_replication/seed${seed}.json" "artifacts/runs/family_replication/seed${seed}" "artifacts/safety_finetuning/${names[i]}"
 done
 run_one artifacts/plans/position_control/full.json artifacts/runs/position_control/full "artifacts/safety_finetuning/${names[0]}"
 python - <<'PY'
import json
from datetime import datetime,timezone
from pathlib import Path
paths=[Path(f'artifacts/runs/family_replication/seed{s}/VERIFIED.json') for s in (42,43,44)]+[Path('artifacts/runs/position_control/full/VERIFIED.json')]
checks=[json.loads(p.read_text()) for p in paths]
assert all(c['complete'] for c in checks) and sum(c['responses'] for c in checks)==2640
out=Path('artifacts/runs/replication_positions_COMPLETED.json')
out.write_text(json.dumps({'verified_at_utc':datetime.now(timezone.utc).isoformat(),'full_responses':2640,'checks':checks},indent=2)+'\n')
print('DONE: all 2,640 full responses completed and telemetry verified.')
print(out)
PY
fi
