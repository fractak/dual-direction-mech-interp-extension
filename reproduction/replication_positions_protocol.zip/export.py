"""Check completed runs and export the two studies as separate blinded batches."""
import copy,json,subprocess,sys
from pathlib import Path
from check import check
from ddmi.publication import validate_plan

def main():
 conditions=[];hashes={};payloads=[]
 for seed,expected in ((42,6),(43,3),(44,3)):
  folder=Path(f'artifacts/runs/family_replication/seed{seed}');plan=json.loads((folder/'plan.json').read_text());run=json.loads((folder/'run.json').read_text())
  check(plan,run);assert len(run['conditions'])==expected and len(plan['payload']['prompts'])==120
  payloads.append(plan['payload']);hashes[f'seed{seed}']=plan['plan_sha256']
  for c in run['conditions']:
   c=copy.deepcopy(c);c['id']=f'seed{seed}_{c["id"]}'
   if c['receiver']=='safety_lora':c['receiver']=f'seed{seed}'
   conditions.append(c)
 assert all(b['prompts']==payloads[0]['prompts'] and all(b['vectors'][v]==payloads[0]['vectors'][v] for v in ('evidence:L20','format:L20')) for b in payloads)
 assert sum(len(c['rows']) for c in conditions)==1440
 out=Path('artifacts/runs/family_replication/combined_for_review.json')
 if out.exists():raise ValueError('Combined review source exists; do not replace a frozen review export')
 out.write_text(json.dumps({'schema_version':2,'complete':True,'component_plan_sha256':hashes,'conditions':conditions},indent=2)+'\n')
 subprocess.run([sys.executable,'scripts/review_responses.py','export','--source',str(out),'--output-dir','artifacts/review/family_replication'],check=True)
 run=Path('artifacts/runs/position_control/full/run.json');plan=run.parent/'plan.json'
 subprocess.run([sys.executable,str(Path(__file__).with_name('check.py')),str(plan),str(run)],check=True)
 subprocess.run([sys.executable,'scripts/review_responses.py','export','--source',str(run),'--output-dir','artifacts/review/position_control'],check=True)
 print('Exported two independent review batches. Keep both PRIVATE_review_map.json files private.')
if __name__=='__main__':main()
