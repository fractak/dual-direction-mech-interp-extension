"""Frozen paired-family analysis for two separate experiments; no pooled new/old test."""
import argparse,collections,hashlib,json
from pathlib import Path
import numpy as np
LABELS=('acknowledgment','instructions','unsupported','other')

def analyze(path,study):
 d=json.loads(path.read_text());assert d['complete'] is True
 g={};ref=None;pairs={}
 modes=['baseline','evidence','format'] if study=='family_replication' else ['baseline','position_final_fixed','position_previous_fixed','position_two_back_fixed','position_user_last_fixed']
 names=['original_instruct','seed42','seed43','seed44'] if study=='family_replication' else ['original_instruct','safety_lora']
 for c in d['conditions']:
  n=c['receiver'];m='baseline' if c['mode']=='observe' else (c['source'] if study=='family_replication' else c['mode'])
  assert n in names and m in modes and (n,m) not in g
  assert c['layer']==20 and c['amount']==(0 if m=='baseline' else 4)
  rows={x['prompt_id']:x for x in c['rows']};assert len(rows)==len(c['rows'])==120
  q={k:(x['prompt'],x['domain']) for k,x in rows.items()};ref=q if ref is None else ref;assert q==ref
  for x in rows.values():
   v=x['independent_review'];assert v['outcome'] in LABELS and (v['a']==v['b'] or v['adjudicated'])
   assert pairs.setdefault((x['prompt'],x['response']),v)==v
  g[n,m]=rows
 assert set(g)=={(n,m) for n in names for m in modes}
 families=sorted({v[1] for v in ref.values()});assert len(families)==30 and all(sum(v[1]==f for v in ref.values())==4 for f in families)
 out={'study':study,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'component_plans':d.get('component_plan_sha256',{'full':d.get('plan_sha256')}),'bootstrap':{'draws':20000,'seed':42,'unit':'paired prompt family','primary_position_multiplicity':'two contrasts, Bonferroni simultaneous 95% using 97.5% marginal intervals'},'review':{},'conditions':{},'analyses':{}}
 ca=collections.Counter(v['a'] for v in pairs.values());cb=collections.Counter(v['b'] for v in pairs.values());n=len(pairs);pa=sum(v['a']==v['b'] for v in pairs.values())/n;pe=sum(ca[k]*cb[k] for k in LABELS)/n**2
 out['review']={'unique_pairs':n,'agreement':pa,'cohen_kappa':None if pe==1 else (pa-pe)/(1-pe),'disagreements':sum(v['a']!=v['b'] for v in pairs.values())}
 for k,rows in g.items():out['conditions']['/'.join(k)]={'counts':{label:sum(x['independent_review']['outcome']==label for x in rows.values()) for label in LABELS},'cap_hits':sum(x['hit_token_limit'] for x in rows.values()),'input_truncated':sum(x['input_truncated'] for x in rows.values())}
 for subset in ('all','uncapped'):
  ids=sorted(k for k in ref if subset=='all' or all(not rows[k]['hit_token_limit'] for rows in g.values()))
  if not ids:
   out['analyses'][subset]={'prompts':0,'status':'No common uncapped prompts; sensitivity unavailable'};continue
  fs=sorted({ref[k][1] for k in ids});mask=np.array([[ref[k][1]==f for k in ids] for f in fs],int);ix=np.random.default_rng(42).integers(0,len(fs),(20000,len(fs)));den=mask.sum(1)[ix].sum(1)
  def ci(v,alpha=.05):
   b=100*(mask@v)[ix].sum(1)/den
   return [float(100*v.mean()),*[float(x) for x in np.quantile(b,[alpha/2,1-alpha/2])]]
  for label in ('acknowledgment','unsupported'):
   for vote in ('outcome','a','b'):
    z={k:np.array([int(rows[i]['independent_review'][vote]==label) for i in ids],float) for k,rows in g.items()}
    if study=='family_replication':
     contrasts={f'{n}/{m}':z[n,m]-z[n,'baseline']-z['original_instruct',m]+z['original_instruct','baseline'] for n in names[1:] for m in modes[1:]}
     interactions={n:contrasts[n+'/evidence']-contrasts[n+'/format'] for n in names[1:]}
     primary=sum(interactions.values())/3
     values={'pooled_interaction':primary,**{f'{n}/interaction':v for n,v in interactions.items()},**contrasts}
     values.update({f'pooled/{m}':sum(contrasts[n+'/'+m] for n in names[1:])/3 for m in modes[1:]})
     result={'contrasts':{k:ci(v) for k,v in values.items()}}
    else:
     rec={m:z['safety_lora',m]-z['safety_lora','baseline']-z['original_instruct',m]+z['original_instruct','baseline'] for m in modes[1:]}
     comparisons={m:rec['position_final_fixed']-rec[m] for m in ('position_user_last_fixed','position_previous_fixed','position_two_back_fixed')}
     result={'receiver_contrasts':{k:ci(v) for k,v in rec.items()},'final_minus_other_pointwise95':{k:ci(v) for k,v in comparisons.items()},'primary_position_simultaneous95':{k:ci(comparisons[k],.025) for k in ('position_user_last_fixed','position_previous_fixed')}}
    result.update(prompts=len(ids),families=len(fs));out['analyses']['/'.join((subset,label,vote))]=result
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('study',choices=('family_replication','position_control'));p.add_argument('reviewed',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();result=analyze(a.reviewed,a.study);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(result['analyses']['all/acknowledgment/outcome'],indent=2))
