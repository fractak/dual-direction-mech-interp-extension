"""Freeze fresh-family replication and fixed-sign position-control plans."""
import argparse,copy,difflib,hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
from ddmi.publication import digest,normalized,validate_plan
from ddmi.provenance import adapter_manifest
BUNDLE=Path(__file__).resolve().parent
RECEIPT=Path('artifacts/plans/replication_positions_freeze.json')
EXPECTED={42:'0bef470a188eb16c7e6c0e83b269564677dd079beef50856c67196420062b784',43:'2276af93980d8709ed266ad98f1274779f31b2bbc8e689ba11661ad8b66747f7',44:'3665e23c16f0d0b9b99f118b8416ffd7c4ee6cea26d18f26704a4e7dc1e30118'}
NAMES={42:'llama31_8b_instruct_safety_lora',43:'llama31_8b_instruct_safety_lora_seed43',44:'llama31_8b_instruct_safety_lora_seed44'}
CODE=['src/ddmi/editing/measured.py','src/ddmi/models/generation.py','src/ddmi/models/positions.py','src/ddmi/publication.py']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inputs():
 return {str(p):sha(p) for p in [*(BUNDLE/n for n in ('freeze.py','run.sh','check.py','analyze.py','export.py','evaluation.txt','PROTOCOL.md','calibration_reference.json')),*(Path(p) for p in CODE)]}
def evaluation():
 rows=[]
 for line in (BUNDLE/'evaluation.txt').read_text().splitlines():
  family,q=line.split('|');q+='?'
  for i,p in enumerate((q,'Can you answer this question: '+q,'Please answer the following: '+q,'I have a question about my setup. '+q)):
   rows.append({'id':f'rep2_{family}_{i}','domain':family,'prompt':p})
 assert len(rows)==len({r['prompt'] for r in rows})==120 and len({r['domain'] for r in rows})==30
 return rows

def freeze():
 if RECEIPT.exists():raise ValueError('Freeze receipt exists; use --verify, do not overwrite')
 prompts=evaluation();parents={};refs=[];reference_files={}
 for seed in (42,43,44):
  path=Path(f'artifacts/plans/fresh_absolute/seed{seed}.json');parent=json.loads(path.read_text());validate_plan(parent)
  assert parent['plan_sha256']==EXPECTED[seed],f'Unexpected parent plan for seed {seed}'
  b=parent['payload'];assert b['config']['max_new_tokens']==512 and len(b['prompts'])==120
  assert all(c['layer']==20 for c in b['conditions'])
  assert b['config']['fixed_direction_receiver_files']==adapter_manifest(Path('artifacts/safety_finetuning')/NAMES[seed])['files']
  parents[seed]=parent;reference_files[str(path)]=sha(path)
  refs.extend(x['prompt'] for x in b['prompts'])
 assert all(parents[s]['payload']['vectors'][k]==parents[42]['payload']['vectors'][k] for s in (43,44) for k in ('evidence:L20','format:L20'))
 for name in ('data/capability_train_pairs.json','data/capability_eval_expanded.json','data/safety_finetuning/train_sft.json','/home/ubuntu/receiver_replication/fresh_prompts.json'):
  path=Path(name);obj=json.loads(path.read_text());reference_files[name]=sha(path)
  rows=obj['rows'] if isinstance(obj,dict) else obj
  for row in rows:
   refs.extend(row[k] for k in ('prompt','capable','incapable') if isinstance(row.get(k),str))
 refs.extend(json.loads((BUNDLE/'calibration_reference.json').read_text()))
 seen={normalized(x) for x in refs};assert not {normalized(x['prompt']) for x in prompts}&seen
 # These are transparent lexical neighbors, not an automated semantic exclusion claim.
 nearest=[]
 for row in prompts[::4]:
  q=normalized(row['prompt']);best=sorted(((difflib.SequenceMatcher(None,q,normalized(x)).ratio(),x) for x in set(refs)),reverse=True)[:3]
  nearest.append({'family':row['domain'],'question':row['prompt'],'nearest_prior':[{'similarity':s,'prompt':p} for s,p in best]})
 frozen_inputs=inputs();files={};protocol_sha=sha(BUNDLE/'PROTOCOL.md')
 for seed in (42,43,44):
  payload=copy.deepcopy(parents[seed]['payload']);receivers=['original_instruct','safety_lora'] if seed==42 else ['safety_lora']
  payload.update(prompts=prompts,parent_plan_sha256=parents[seed]['plan_sha256'],prompt_file_sha256=sha(BUNDLE/'evaluation.txt'),exact_frozen_prompt_overlap=0)
  payload['config'].update(max_new_tokens=512,record_position_controls=False)
  payload['interpretation']='Independent evaluation-family replication of the original pooled acknowledgment evidence-minus-format receiver contrast; same directions and tested adapters. Not an independent architecture or training-recipe replication.'
  payload['prospective_extension']={'protocol_sha256':protocol_sha,'name':'family_replication','new_families':30,'lexical_screen_only':True}
  cond=[dict(receiver=n,layer=20,mode=mode,amount=amt,source=src,random_seed=None) for n in receivers for mode,amt,src in [('observe',0,'evidence'),('absolute_l2',4.,'evidence'),('absolute_l2',4.,'format')]]
  for i,c in enumerate(cond):c['id']=f'c{i:04d}'
  for smoke in (False,True):
   b=copy.deepcopy(payload);b['conditions']=cond
   if smoke:b['prompts']=prompts[:1];b['config']['max_new_tokens']=32
   b['planned_responses']=len(cond)*len(b['prompts']);plan={'payload':b,'plan_sha256':digest(b)};validate_plan(plan)
   files[Path(f'artifacts/plans/family_replication/seed{seed}{"_smoke" if smoke else ""}.json')]=plan
 base=copy.deepcopy(parents[42]['payload']);base['config'].update(record_position_controls=True,max_new_tokens=512)
 base['interpretation']='Post-primary position-mask control on the prior 120 families/wordings: fixed subtraction at four exact token positions; one original/seed42 checkpoint pair.'
 base['interpretation']=base['interpretation'].replace('120 families/wordings','120 prompts in 30 families')
 base['parent_plan_sha256']=parents[42]['plan_sha256'];base['prospective_extension']={'protocol_sha256':protocol_sha,'name':'position_control'}
 modes=['observe','position_final_fixed','position_previous_fixed','position_two_back_fixed','position_user_last_fixed']
 base['conditions']=[dict(id=f'c{i:04d}',receiver=n,layer=20,mode=m,amount=0 if m=='observe' else 4.,source='evidence',random_seed=None) for i,(n,m) in enumerate((n,m) for n in ['original_instruct','safety_lora'] for m in modes)]
 for smoke in (False,True):
  b=copy.deepcopy(base)
  if smoke:b['prompts']=b['prompts'][:1];b['config']['max_new_tokens']=32
  b['planned_responses']=len(b['conditions'])*len(b['prompts']);plan={'payload':b,'plan_sha256':digest(b)};validate_plan(plan)
  files[Path(f'artifacts/plans/position_control/{"smoke" if smoke else "full"}.json')]=plan
 for path in files:
  if path.exists():raise ValueError(f'Refusing to overwrite {path}')
 receipt={'created_at_utc':datetime.now(timezone.utc).isoformat(),'timestamp_status':'Internal freeze before generation, not external preregistration','protocol_sha256':protocol_sha,'inputs':frozen_inputs,'reference_files':reference_files,'screened_prior_prompt_count':len(refs),'normalized_exact_overlap':0,'semantic_screen':'Author inspected the named object/task families against supplied historical evaluation and calibration lists; shared access-limit task structure is intentional. Lexical screening does not certify semantic disjointness.','nearest_prior':nearest,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'plans':{str(p):v['plan_sha256'] for p,v in files.items()}}
 for path,plan in files.items():
  path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(plan,indent=2,allow_nan=False)+'\n');print(path,plan['payload']['planned_responses'],plan['plan_sha256'])
 RECEIPT.write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n');print('Frozen 1,440 replication + 1,200 position-control full responses (22 additional smoke responses).')

def verify():
 receipt=json.loads(RECEIPT.read_text());assert inputs()==receipt['inputs'],'Bundle or execution code changed after freeze'
 for path,h in receipt['reference_files'].items():assert sha(path)==h,f'Frozen reference changed: {path}'
 for path,h in receipt['plans'].items():
  plan=json.loads(Path(path).read_text());validate_plan(plan);assert plan['plan_sha256']==h
 print('Freeze inputs, code, reference files and all eight plans verified.')
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--verify',action='store_true');a=p.parse_args()
 try:verify() if a.verify else freeze()
 except (ValueError,AssertionError,FileNotFoundError) as e:p.exit(2,str(e)+'\n')
