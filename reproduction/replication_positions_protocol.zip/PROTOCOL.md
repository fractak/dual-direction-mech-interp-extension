# Two experiments, frozen before generation

These plans are follow-ups designed after observing the original primary study,
its localization follow-up and earlier controls. The local freeze record precedes
new generation; it is not external preregistration. Do not choose prompts,
directions, doses, outcome rules or contrasts after seeing new responses.

## A. Independent evaluation-family replication

Question: does the pooled acknowledgment receiver-by-direction interaction
replicate on a new set of object/task families, with existing directions and
receivers held fixed?

- 30 named families, four original-style question wrappers per family: 120 prompts.
  Evaluation text is distributed in evaluation.txt and frozen verbatim.
- Original Llama plus the existing mixed-data adapters from seeds 42, 43 and 44.
- Baseline, evidence direction, format direction. The exact original evidence
  and format vectors are reused across all four receivers.
- Layer 20; absolute L2 dose 4.0; original projection-dependent sign rule;
  512-token cap; same pinned model revision, NF4 configuration, greedy generation
  and chat template as the original frozen primary plans.
- 12 conditions x 120 = 1,440 responses. Seed42 includes the original receiver;
  it has 720 responses. Seeds43 and44 have360 each.

Primary outcome: acknowledgment under the established four-category rubric,
with unsupported assertions taking precedence over acknowledgment, then usable
checking instructions, then other. Merely asking generically for more details
is insufficient for acknowledgment. Two independent blinded reviews, followed
by documented adjudication. Report agreement before adjudication and repeat the
primary estimate under each review stream separately. Preserve original labels.

For each direction, compute each adapted receiver's baseline-to-edit change,
subtract the original receiver's change, and average across the three adapters.
The primary interaction is evidence receiver contrast minus format receiver
contrast. This also equals mean-adapter evidence-minus-format minus original
evidence-minus-format, because the baselines cancel. Report its point estimate
and paired 95% family-bootstrap percentile interval (20,000 draws, NumPy
`default_rng(42)`). Resample all four phrasings and every receiver/condition
jointly within each family. Report each seed, both component direction contrasts,
and unsupported assertions as secondary outcomes.

Keep the new replication estimate separate from the original -45-point result.
Do not pool old and new prompts for the primary replication test. Matching the
old effect magnitude is not a success criterion. A negative interval excluding
zero supports the directional interaction on these new families. A broad or
zero-crossing interval is inconclusive; an opposite effect or substantial
attenuation must be reported. The pooled result describes these three adapters,
not a population of independently sampled training runs.

Screening: questions were authored for different named object/task contexts
from the supplied old evaluation and crossed calibration lists. Exact normalized
matches are forbidden against those lists, the earlier60 fresh prompts and
frozen adaptation data. The receipt records hashes and top lexical neighbors.
This is a documented content/lexical screen, not a guarantee of semantic
independence: all families intentionally share the access-limit task. There is
no new architecture, training recipe or direction extraction in this replication.

## B. Chat-template position control

Same old 120 prompts /30 families, original and seed42 Llama, shared original
evidence direction, layer20, absolute dose4, cap512. This is not an independent
evaluation-set replication.

Generate matched new baselines and four single-position edits in each receiver:

1. final prefill token;
2. immediately preceding prefill token;
3. two positions before final prefill;
4. last token of actual user content.

All edits use fixed subtraction `-4d`. Do not switch signs according to the local
projection. Each edited response has exactly one selected layer20 token in
prefill, with decoding unedited. Each baseline has zero displacement throughout.
This gives 10 conditions x120 =1,200 new responses including240 baselines.

Locate user content through character offsets on the exact rendered chat prompt,
require untruncated identical tokenization, and select its last complete token.
Do not assume a fixed offset from the end. Require all four indices to be
distinct. Record full prefill/generated token IDs, all four indices, neighboring
token strings and IDs, signed projection, assigned sign, signed displacement and
L2 displacement at each recorded position. The final user token can be punctuation;
it is not asserted to be a unique semantic summary position.

Primary position comparisons: final-token receiver contrast minus last-user-
content contrast, and final-token receiver contrast minus immediately preceding
contrast. Report both with Bonferroni simultaneous95% intervals, using97.5%
marginal paired family-bootstrap intervals. This family has two comparisons.
Also report every mask's receiver contrast with pointwise95% intervals and the
two-back comparison as secondary. Use the same20,000 family draws and RNG42.
Keep timing, dose, direction and fixed sign constant. A larger final effect
supports localization under these choices, not a necessary or unique mechanism.

## Both studies

Report all prompts, counts by outcome and cap hits by condition. Repeat each
study on the subset where all of its compared responses finish below the cap;
this is an outcome-selected sensitivity analysis, not a causal cap estimate.
Do not silently reassign identical text pairs across review batches; document
inconsistencies and, if present, analyze an explicitly stated harmonization
policy separately. Neither secondary analyses nor reviewer choices may be used
to change the frozen primary contrast.

A one-prompt/32-token smoke gate runs each new condition before the full runs.
All plans, code hashes, protocol and prompt hashes, receiver weights and parent
plans are frozen before even smoke generation. Smoke caps are expected and are
not a reason to change the full512-token protocol. Full runs are sequential.
Intermittent progress uses the existing per-response journal and condition
checkpoints. Resume uses the existing strict recovery checks. The completion
receipt is written only after every full run passes the telemetry checker.
