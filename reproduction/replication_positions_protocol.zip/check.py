"""Validate frozen conditions, prompt identity and intervention telemetry."""
import argparse,json,math
from pathlib import Path
from ddmi.publication import validate_plan
from ddmi.models.positions import POSITION_CONTROL_MODES,locate_positions

def check(plan,run,tokenizer=None):
 validate_plan(plan);b=plan['payload'];position=b['config'].get('record_position_controls',False)
 assert run.get('complete') is True and run['plan_sha256']==plan['plan_sha256'],'Run incomplete or plan differs'
 assert len(run['conditions'])==len(b['conditions'])
 checked=edited=0;worst=0.;caps=0;position_refs={}
 for c,expected in zip(run['conditions'],b['conditions']):
  assert all(c[k]==v for k,v in expected.items()),'Condition differs from plan'
  assert len(c['rows'])==len(b['prompts'])
  for x,p in zip(c['rows'],b['prompts']):
   assert (x['prompt_id'],x['prompt'],x['domain'])==(p['id'],p['prompt'],p['domain'])
   assert not x['input_truncated'] and x['generated_tokens']>0
   caps+=bool(x['hit_token_limit']);calls=x['telemetry']['evidence' if c['source']=='evidence' else 'format']
   assert len(calls)==x['generated_tokens'],'Cache/hook alignment differs'
   if len(b['prompts'])==1:assert len(calls)>1,'Smoke must exercise decoding'
   if position:
    assert tokenizer is not None
    ids=x['prefill_token_ids'];assert len(ids)==x['input_tokens'] and len(x['generated_token_ids'])==x['generated_tokens']
    opts={} if b['config'].get('enable_thinking') is None else {'enable_thinking':b['config']['enable_thinking']}
    rendered=tokenizer.apply_chat_template([{'role':'user','content':x['prompt']}],tokenize=False,add_generation_prompt=True,**opts)
    tokens=tokenizer(rendered,truncation=False,return_offsets_mapping=True)
    assert tokens['input_ids']==ids,'Saved prompt tokens differ from frozen tokenizer'
    indices=locate_positions(rendered,x['prompt'],ids,tokens['offset_mapping'])
    assert x['position_control']['indices']==indices
    assert position_refs.setdefault(x['prompt_id'],indices)==indices
    target=None if c['mode']=='observe' else indices[POSITION_CONTROL_MODES[c['mode']]]
    assert x['position_control']['selected_index']==target
   for i,call in enumerate(calls):
    phase='prefill' if i==0 else 'decode';assert call['phase']==phase and call['tokens']==(x['input_tokens'] if i==0 else 1)
    if position and c['mode']!='observe':
     d=call['token_localization'];size=call['tokens'];assert all(len(v)==size for v in d.values())
     for j,(proj,sign,signed,norm) in enumerate(zip(d['projection'],d['sign'],d['signed_displacement'],d['displacement_l2'])):
      wanted=-1 if i==0 and j==target else 0
      error=max(abs(signed-wanted*4),abs(norm-abs(wanted)*4))
      assert all(math.isfinite(v) for v in (proj,signed,norm)) and sign==wanted and error<=(.04 if wanted else 0),'Position mask/sign/displacement failed'
      worst=max(worst,error);checked+=1;edited+=bool(wanted)
    else:
     for key in ('min','max'):
      norm=call['displacement_l2'][key];error=abs(norm-c['amount'])
      assert math.isfinite(norm) and error<=c['amount']*.01,'Absolute displacement failed'
      worst=max(worst,error)
     checked+=call['tokens'];edited+=call['tokens'] if c['amount'] else 0
 return {'complete':True,'plan_sha256':plan['plan_sha256'],'conditions':len(b['conditions']),'responses':sum(len(c['rows']) for c in run['conditions']),'token_positions':checked,'edited_positions':edited,'maximum_displacement_error':worst,'cap_hits':caps}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('plan',type=Path);p.add_argument('run',type=Path);a=p.parse_args()
 plan=json.loads(a.plan.read_text());run=json.loads(a.run.read_text());tokenizer=None
 if plan['payload']['config'].get('record_position_controls'):
  from transformers import AutoTokenizer
  tokenizer=AutoTokenizer.from_pretrained(plan['payload']['model_id'],revision=plan['payload']['config']['model_revision'],local_files_only=True)
 result=check(plan,run,tokenizer)
 out=a.run.parent/'VERIFIED.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
