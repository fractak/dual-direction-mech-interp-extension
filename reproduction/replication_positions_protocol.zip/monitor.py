"""Read-only journal counter. Completion requires verified checks, not just a count."""
import json
from pathlib import Path

def journal_status(path):
 count=0
 with path.open('rb') as f:
  while chunk:=f.read(1024*1024):count+=chunk.count(b'\n')
  end=f.tell();size=min(end,1024*1024);f.seek(end-size);tail=f.read()
  while tail.count(b'\n')<2 and size<end:
   size=min(end,size*2);f.seek(end-size);tail=f.read()
 if not tail.endswith(b'\n'):tail=tail.rsplit(b'\n',1)[0]+b'\n' if b'\n' in tail else b''
 lines=tail.splitlines()
 last={}
 if lines:
  try:last=json.loads(lines[-1])
  except json.JSONDecodeError:pass
 return count,last

def main():
 total=0
 for label,folder,expected in [(f'replication seed{s}',Path(f'artifacts/runs/family_replication/seed{s}'),n) for s,n in ((42,720),(43,360),(44,360))]+[('position control',Path('artifacts/runs/position_control/full'),1200)]:
  path=folder/'responses.jsonl'
  if not path.exists():print(f'{label}: awaiting start (0/{expected})');continue
  count,last=journal_status(path);total+=count
  verified=folder/'VERIFIED.json';status='VERIFIED' if verified.exists() else 'not yet verified'
  row=last.get('row',{});print(f'{label}: {count}/{expected} saved; {status}; last {last.get("condition_id","?")}/{row.get("prompt_id","?")}')
 print(f'Full-study total: {total}/2640 saved')
 if Path('artifacts/runs/replication_positions_COMPLETED.json').exists():print('DONE: both full experiments completed and verified.')
 else:print('A final count alone does not establish completion; wait for DONE and the completion receipt.')
if __name__=='__main__':main()
