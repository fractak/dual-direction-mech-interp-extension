# Fresh-family replication and chat-template position control

This bundle adds two separate experiments to the existing Llama study. The
manuscript source stays separate. No new training or direction extraction is
required. Total full generation: 2,640 responses, plus22 smoke responses.

Requirements: the existing token-localization code patch must already be applied;
original fresh_absolute/seed42,seed43,seed44 plans and three adapters must remain
at their existing paths. The freeze pins those exact original plans. All GPU work
runs sequentially. The code patch does not include the earlier release-analysis
patch, and works whether or not that analysis update has been applied.

## Install and freeze, once

Download replication_positions.zip, upload it to /home/ubuntu, then paste:

```bash
cd ~/dual-direction-mech-interp
source .venv/bin/activate

python -m zipfile -e /home/ubuntu/replication_positions.zip /home/ubuntu/replication_positions &&
git apply --check /home/ubuntu/replication_positions/replication_positions.patch &&
git apply /home/ubuntu/replication_positions/replication_positions.patch &&
bash /home/ubuntu/replication_positions/run.sh freeze
```

The freeze runs8 unit tests, creates eight frozen plans, and records code,
protocol, prompt, reference-file and adapter hashes. The two tensor tests require
PyTorch, which is installed in your server venv. Both must pass there. The receipt
is `artifacts/plans/replication_positions_freeze.json`. Do not reapply the patch
or overwrite plans after freezing. Verify an existing freeze with:

```bash
bash /home/ubuntu/replication_positions/run.sh verify
```

## Launch both sequentially in tmux

```bash
tmux new-session -s replication-positions
```

Inside that tmux session:

```bash
cd ~/dual-direction-mech-interp
source .venv/bin/activate
set -o pipefail
bash /home/ubuntu/replication_positions/run.sh all 2>&1 | tee /home/ubuntu/replication_positions/run.log
```

Detach with Ctrl-b, then d. The runner smoke-tests all22 new condition instances
at32 tokens, verifies them, runs the 1,440-response family replication, then the
1,200-response position control, and verifies every full run. A smoke validation
failure stops the pipeline before full generation. Run on the A30 without another
GPU job occupying it.

## Monitor from another terminal

```bash
cd ~/dual-direction-mech-interp
watch -n 30 '.venv/bin/python /home/ubuntu/replication_positions/monitor.py'
```

For console output or GPU utilization:

```bash
tmux attach -t replication-positions
# Detach again: Ctrl-b, then d.
nvidia-smi
```

Expected full-response counts:

| Run | Responses |
|---|---:|
| Replication seed42, including original | 720 |
| Replication seed43 | 360 |
| Replication seed44 | 360 |
| Position control, original plus seed42 | 1200 |
| Total | 2640 |

Wait for `DONE: all 2,640 full responses completed and telemetry verified.`
and `artifacts/runs/replication_positions_COMPLETED.json`.
A journal counter reaching2640 alone is not the completion check.

If interrupted, activate the same venv and rerun the same `run.sh all` command.
Completed runs are checked and skipped; partial runs use the existing --resume
recovery. Do not delete or overwrite outputs to restart.

## Export two separate blinded-review batches

Once both full experiments are verified:

```bash
cd ~/dual-direction-mech-interp
source .venv/bin/activate
bash /home/ubuntu/replication_positions/run.sh export
```

Send each reviewer their corresponding CSV separately for each study:

- artifacts/review/family_replication/reviewer_A.csv to reviewerA;
- artifacts/review/family_replication/reviewer_B.csv to reviewerB;
- artifacts/review/position_control/reviewer_A.csv to reviewerA;
- artifacts/review/position_control/reviewer_B.csv to reviewerB.

Keep each PRIVATE_review_map.json private. Do not mix the study batches or expose
receiver/condition mappings to reviewers. Use the established four-category
rubric in PROTOCOL.md and preserve prompt/response text and IDs. The export reports
the actual unique-pair count; do not assume all response rows are unique.

After review, merge/adjudicate with scripts/review_responses.py using the map for
the corresponding study. Then reproduce the frozen analyses:

```bash
python /home/ubuntu/replication_positions/analyze.py family_replication \
  artifacts/review/family_replication_resolved/reviewed_source.json \
  --output artifacts/analysis/family_replication_results.json

python /home/ubuntu/replication_positions/analyze.py position_control \
  artifacts/review/position_control_resolved/reviewed_source.json \
  --output artifacts/analysis/position_control_results.json
```

The original primary result remains a separate estimate. Position contrasts use
new matched baselines and fixed subtraction at all four positions. See PROTOCOL.md
for the frozen hypotheses, multiplicity rule, caps, family bootstrap and limits.

## Validation completed before distribution

Six pure-Python boundary tests pass locally; two tensor tests are deferred to the
server because PyTorch is unavailable in the authoring runtime. Synthetic tests
also verify all eight plans/counts, freeze integrity, an analytically known
-100-point replication interaction, correct position masks, rejection of an
unselected-position leak, and monitoring of a partial journal line. Python files
compile, Bash syntax passes, and the patch applies cleanly to the repository
state after the earlier token-localization patch. Actual tokenizer/GPU validation
is gated by the server smoke runs, not claimed as completed here.
