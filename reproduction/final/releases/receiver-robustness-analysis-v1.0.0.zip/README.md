# Receiver robustness analysis release v1.0.0

The prompt-level JSON contains stable prompt and family IDs, condition
assignments, cap flags, the two reviewer labels, and the adjudicated labels.
Observations in each condition align with the prompt list in order. Conditions
are keyed by receiver, absolute L2 dose, and direction. Dose 0 is the baseline.
The JSON includes no model outputs, reviewer notes, or private review map.

From the extracted release, run with Python 3 and NumPy.

    python robustness_release.py verify reviewed_labels.json results.json

The verifier reproduces the two primary estimates, pooled secondary intervals,
both reviewer sensitivities, the uncapped primary intervals, and the reported
per-cell acknowledgment and unsupported counts. The bootstrap resamples prompt
families and holds the vectors and trained receivers fixed. This release
recomputes the estimates from saved labels. It does not regenerate outputs or
repeat the model judging.
