"""Freeze token-localization plans from the original fresh-absolute seed-42 plan."""
import copy
import json
from pathlib import Path

from ddmi.publication import digest, validate_plan

parent = json.loads(Path("artifacts/plans/fresh_absolute/seed42.json").read_text())
validate_plan(parent)
base = parent["payload"]
conditions = [c for c in base["conditions"] if c["source"] == "evidence"]
if (len(conditions) != 2
        or {c["receiver"] for c in conditions} != {"original_instruct", "safety_lora"}
        or any((c["layer"], c["mode"], c["amount"]) != (20, "absolute_l2", 4)
               for c in conditions)
        or len(base["prompts"]) != 120
        or len({p["domain"] for p in base["prompts"]}) != 30
        or base["config"]["max_new_tokens"] != 512
        or "evidence:L20" not in base["vectors"]):
    raise SystemExit("Unexpected fresh-absolute seed-42 plan.")
out = Path("artifacts/plans/token_localization")
out.mkdir(parents=True, exist_ok=False)
for name in ("full", "smoke"):
    payload = copy.deepcopy(base)
    payload["parent_plan_sha256"] = parent["plan_sha256"]
    payload["interpretation"] = "Token-position and sign-rule localization on the prior evidence-direction evaluation."
    payload["conditions"] = [
        dict(c, mode=mode) for c in conditions
        for mode in ("last_prefill_fixed", "early_prefill_adaptive", "early_prefill_fixed",
                     "decode_only_adaptive", "decode_only_fixed", "early_fixed_else_adaptive")
    ]
    for i, c in enumerate(payload["conditions"]):
        c["id"] = f"c{i:04d}"
    if name == "smoke":
        payload["prompts"] = payload["prompts"][:1]
        payload["config"]["max_new_tokens"] = 32
    payload["planned_responses"] = len(payload["prompts"]) * len(payload["conditions"])
    plan = {"payload": payload, "plan_sha256": digest(payload)}
    validate_plan(plan)
    (out / f"{name}.json").write_text(json.dumps(plan, indent=2, allow_nan=False)+"\n")
    print(name, payload["planned_responses"], plan["plan_sha256"])
