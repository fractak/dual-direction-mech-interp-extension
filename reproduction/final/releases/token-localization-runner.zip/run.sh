#!/usr/bin/env bash
set -euo pipefail
bundle=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
plans=artifacts/plans/token_localization
runs=artifacts/runs/token_localization
adapter=artifacts/safety_finetuning/llama31_8b_instruct_safety_lora
export HF_HUB_OFFLINE=1
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
case "${1:-}" in
  freeze) python "$bundle/freeze.py"; exit ;;
  smoke) stage=smoke ;;
  run)
    stage=full
    python "$bundle/check.py" "$plans/smoke.json" "$runs/smoke/run.json"
    ;;
  *) echo "Usage: bash run.sh freeze|smoke|run" >&2; exit 2 ;;
esac
output="$runs/$stage"
resume=()
if [[ -f "$output/run.json" ]]; then resume=(--resume); fi
if [[ ! -f "$output/run.json" ]] ||
  ! python -c 'import json,sys; sys.exit(json.load(open(sys.argv[1])).get("complete") is not True)' "$output/run.json"; then
  python scripts/run_publication_study.py run --plan "$plans/$stage.json" \
    --adapter-path "$adapter" --output-dir "$output" "${resume[@]}"
fi
python "$bundle/check.py" "$plans/$stage.json" "$output/run.json"
