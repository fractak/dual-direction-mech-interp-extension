"""Verify mask, sign, and measured displacement at every recorded position."""
import argparse
import json
import math
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("plan", type=Path)
parser.add_argument("run", type=Path)
args = parser.parse_args()
plan = json.loads(args.plan.read_text())
run = json.loads(args.run.read_text())
expected = plan["payload"]
if run.get("complete") is not True or run["plan_sha256"] != plan["plan_sha256"]:
    parser.error("Run is incomplete or belongs to another plan.")
if len(run["conditions"]) != len(expected["conditions"]):
    parser.error("Unexpected condition count.")

def rule(mode, phase, last):
    if mode == "early_fixed_else_adaptive":
        return "fixed" if phase == "prefill" and not last else "adaptive"
    if phase == "decode":
        return {"decode_only_adaptive":"adaptive", "decode_only_fixed":"fixed"}.get(mode)
    if last:
        return "fixed" if mode == "last_prefill_fixed" else None
    return {"early_prefill_adaptive":"adaptive", "early_prefill_fixed":"fixed"}.get(mode)

worst = checked = edited = 0
for c, frozen in zip(run["conditions"], expected["conditions"]):
    if any(c[k] != v for k,v in frozen.items()):
        parser.error(f"Condition differs from plan: {c['id']}")
    if [r["prompt_id"] for r in c["rows"]] != [p["id"] for p in expected["prompts"]]:
        parser.error(f"Prompt IDs differ from plan: {c['id']}")
    for r in c["rows"]:
        calls = r["telemetry"]["evidence"]
        prompt_ids, generated_ids = r["prefill_token_ids"], r["generated_token_ids"]
        if (r["input_truncated"] or len(prompt_ids) != r["input_tokens"]
                or len(generated_ids) != r["generated_tokens"]
                or not generated_ids or len(calls) != len(generated_ids)):
            parser.error(f"Token-to-hook alignment failed: {c['id']}/{r['prompt_id']}")
        if len(expected["prompts"]) == 1 and len(calls) < 2:
            parser.error("Smoke did not exercise decoding.")
        for i, call in enumerate(calls):
            phase = "decode" if i else "prefill"
            size = 1 if i else len(prompt_ids)
            data = call["token_localization"]
            if call["phase"] != phase or call["tokens"] != size or any(len(v)!=size for v in data.values()):
                parser.error(f"Unexpected hook shape: {c['id']}/{r['prompt_id']}")
            for j,(projection,sign,signed,norm) in enumerate(zip(
                data["projection"],data["sign"],data["signed_displacement"],data["displacement_l2"]
            )):
                selected = rule(c["mode"],phase,j==size-1)
                wanted = 0 if selected is None else (1 if selected=="adaptive" and projection<0 else -1)
                dose = c["amount"]
                error = max(abs(signed-wanted*dose),abs(norm-abs(wanted)*dose))
                if (not all(math.isfinite(v) for v in (projection,signed,norm))
                        or sign != wanted or error > (dose*.01 if wanted else 0)):
                    parser.error(f"Mask or displacement mismatch: {c['id']}/{r['prompt_id']}/{i}/{j}")
                if c["mode"]=="last_prefill_fixed" and not i and j==size-1 and projection<0:
                    parser.error("Final prefill projection is negative. The shared final-token condition is not equivalent to adaptive.")
                worst=max(worst,error)
                checked+=1
                edited+=bool(wanted)
print(f"Checked {checked} tokens ({edited} edited); maximum displacement error {worst:.6f}.")
