# Token-position and sign-rule localization

Follow-up on the same 120 prompts and 30 families, with the original and
seed-42 Llama receivers, original evidence direction, layer 20, absolute
dose 4.0, and a 512-token cap. Use the established blinded rubric. Reuse
the original unedited, full adaptive, and full fixed-subtraction responses.

New cells per receiver are final-prefill subtraction only, earlier-prefill
adaptive only, earlier-prefill subtraction only, decode adaptive only,
decode subtraction only, and full adaptive except for fixed subtraction
on earlier prefill positions. This gives 1,440 new responses. Final prefill
subtraction represents both rules at that position only if its pre-edit
projection is nonnegative, which the checker requires on every prompt.

For each cell report the adapted-minus-original change in acknowledgment
against the reused baseline. Report adaptive minus fixed within the earlier
prefill and decode masks, and full adaptive minus the in-context earlier
prefill replacement. Use paired family-bootstrap percentile 95% intervals
with 20,000 NumPy default_rng draws and seed 42. Report final-prefill-only
against baseline as a sufficiency check, unsupported assertions separately,
and the full adaptive-minus-fixed difference as a reference. Report cap
hits and an uncapped sensitivity subset if needed. Effects can interact.

Telemetry records signed projections, assigned signs, and post-cast signed
and norm displacement as aligned token arrays. Prefill positions index the
prefill token IDs. Decode hook call i (starting at 1) processes generated
token i-1 (zero-based). The final generated token has no subsequent hook
call. Decode histories can differ across conditions. Smoke verifies zero
movement outside masks and signed and norm displacement within 1% inside.
