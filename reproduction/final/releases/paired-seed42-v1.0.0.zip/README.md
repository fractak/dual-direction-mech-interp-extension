# Paired seed-42 analysis v1.0.0

Run with Python 3 and NumPy (verified with NumPy 2.3.5).

    python paired_model_comparison.py > recomputed.json
    diff -u paired_model_comparison.json recomputed.json

The Llama and Qwen family counts contain four phrasings per family and cell.
The analysis selects the unadapted and seed-42 receivers in each model.
It independently resamples the 30 families in each prompt bank, using
the same draws for both models. The gap is the Llama shift minus the
Qwen shift, in percentage points.

Cap counts in these tables are aggregated by family and condition. A common
uncapped-prompt analysis requires prompt IDs, cap flags, and outcome labels
from the per-response review exports for both models.
